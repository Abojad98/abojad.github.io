# most powerfull single file libraries

lib name | home page | language
---------|-----------|----------
simple html dom | [Simple Html Dom](./simple-html-dom.txt) | php
